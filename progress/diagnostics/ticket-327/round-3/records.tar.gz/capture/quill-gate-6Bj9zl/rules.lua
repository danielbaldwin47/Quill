QUILL_GATE_RULES = QUILL_GATE_RULES or {}
local C = "^io\\.github\\.danielbaldwin47\\.Quill$"
local D = "^quill$"
local function rule(t) t.match = { class = C } QUILL_GATE_RULES[#QUILL_GATE_RULES + 1] = hl.window_rule(t) end
local function dialog(t) t.match = { class = D } QUILL_GATE_RULES[#QUILL_GATE_RULES + 1] = hl.window_rule(t) end
rule({ name = "quill-gate-workspace", workspace = "3 silent" })
rule({ name = "quill-gate-float", float = true })
rule({ name = "quill-gate-size", size = "1440 900" })
rule({ name = "quill-gate-move", move = "80 50" })
rule({ name = "quill-gate-decoration", no_anim = true, border_size = 0, rounding = 0, no_shadow = true, no_blur = true, no_dim = true, opacity = "1.0 1.0", tag = "-default-opacity" })
dialog({ name = "quill-gate-dialog-workspace", workspace = "3 silent" })
dialog({ name = "quill-gate-dialog-float", float = true })
dialog({ name = "quill-gate-dialog-decoration", no_anim = true, border_size = 0, rounding = 0, no_shadow = true, no_blur = true, no_dim = true, opacity = "1.0 1.0", tag = "-default-opacity" })
